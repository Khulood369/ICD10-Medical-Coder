import tkinter as tk
from tkinter import filedialog, messagebox
import fitz  # PyMuPDF
import csv
import re
from pathlib import Path

CSV_PATH = 'icd10.csv'

SYNONYMS = {
    "hypertension": [r"hypertension", r"htn", r"high blood pressure"],
    "diabetes mellitus type 2": [r"type ?2 diabetes", r"t2dm", r"dm ?2", r"diabetes mellitus type ?2"],
    "asthma": [r"asthma", r"bronchial asthma"],
    "pneumonia": [r"pneumonia", r"pneumonic"],
    "chronic bronchitis": [r"chronic bronchitis", r"copd(?!\w)", r"chronic obstructive bronchitis"],
    "myocardial infarction": [r"myocardial infarction", r"\bmi\b", r"acute coronary syndrome", r"acs"],
}

def load_icd10_codes(file_path):
    codes = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader, None)
            for row in reader:
                if len(row) >= 2:
                    disease = row[0].strip().lower()
                    code = row[1].strip()
                    if disease:
                        codes[disease] = code
    except FileNotFoundError:
        return None
    return codes

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    texts = []
    for i in range(len(doc)):
        page = doc.load_page(i)
        texts.append(page.get_text())
    doc.close()
    return "\n".join(texts)

def find_matches(text, icd10_codes):
    found = []
    text_lower = text.lower()
    for disease, code in icd10_codes.items():
        patterns = SYNONYMS.get(disease, [re.escape(disease)])
        for pat in patterns:
            pattern = re.compile(pat, flags=re.IGNORECASE)
            for m in pattern.finditer(text):
                start = max(m.start() - 40, 0)
                end = min(m.end() + 40, len(text))
                context = text[start:end].replace('\n', ' ')
                found.append({
                    "disease": disease.title(),
                    "code": code,
                    "match_text": m.group(0),
                    "context": context
                })
    unique = {}
    for item in found:
        key = (item["disease"], item["code"])
        if key not in unique:
            unique[key] = item
    return list(unique.values())

def process_report():
    file_path = filedialog.askopenfilename(
        title="اختر التقرير الطبي (PDF)",
        filetypes=[("PDF files", "*.pdf")]
    )
    if not file_path:
        return

    output_text.delete("1.0", tk.END)
    status_var.set(f"الملف: {Path(file_path).name}")

    icd10_codes = load_icd10_codes(CSV_PATH)
    if not icd10_codes:
        messagebox.showerror("خطأ", f"لم يتم العثور على ملف الأكواد: {CSV_PATH}")
        return

    try:
        full_text = extract_text_from_pdf(file_path)
    except Exception as e:
        messagebox.showerror("خطأ في قراءة PDF", str(e))
        return

    matches = find_matches(full_text, icd10_codes)

    if matches:
        output_text.insert(tk.END, "✅ تم العثور على تطابقات محتملة:\n\n")
        for item in matches:
            output_text.insert(tk.END, f"المرض: {item['disease']}\n")
            output_text.insert(tk.END, f"الكود: {item['code']}\n")
            output_text.insert(tk.END, f"التطابق: {item['match_text']}\n")
            output_text.insert(tk.END, f"السياق: …{item['context']}…\n")
            output_text.insert(tk.END, "—" * 25 + "\n")
    else:
        output_text.insert(tk.END, "⚠️ لم يتم العثور على تطابقات.\n")

def reset_view():
    output_text.delete("1.0", tk.END)
    status_var.set("جاهز")

root = tk.Tk()
root.title("مدقق أكواد التقارير الطبية (ICD-10)")
root.geometry("760x520")

top_frame = tk.Frame(root, padx=10, pady=10)
top_frame.pack(side=tk.TOP, fill=tk.X)

btn_load = tk.Button(top_frame, text="تحميل تقرير طبي (PDF)", command=process_report, font=("Arial", 12))
btn_load.pack(side=tk.LEFT)

btn_reset = tk.Button(top_frame, text="إعادة تعيين", command=reset_view, font=("Arial", 12))
btn_reset.pack(side=tk.LEFT, padx=8)

status_var = tk.StringVar(value="جاهز")
status_label = tk.Label(top_frame, textvariable=status_var, fg="gray")
status_label.pack(side=tk.LEFT, padx=12)

output_text = tk.Text(root, wrap=tk.WORD, font=("Arial", 11), padx=12, pady=12)
output_text.pack(expand=True, fill=tk.BOTH)

root.mainloop()
